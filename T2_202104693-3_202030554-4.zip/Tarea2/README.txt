Esta tarea consiste en la implementación de una base de datos utilizando php y mysql.

Para ejecutarlo es necesario tener instalado xampp y estar ejecutando el servidor apache y mysql de forma simultánea.

ingresar a localhost/<nombre de la carpeta> y seleccionar el archivo login.php.

Integrantes:

Ignacio González rol: 202104693-3
Ignacio Panes	 rol: 202030554-4